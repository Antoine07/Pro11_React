export const CALCUL_TOKENS = 'CALCUL_TOKENS';
export const ADD_AMOUNT = 'ADD_AMOUNT';
export const RESET = 'RESET';
