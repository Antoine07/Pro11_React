
import * as firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyB_GVwckXjd0iX73Di99dvsoP7QXsfwTwM",
  authDomain: "music-2020-f6d88.firebaseapp.com",
  databaseURL: "https://music-2020-f6d88.firebaseio.com",
  projectId: "music-2020-f6d88",
  storageBucket: "music-2020-f6d88.appspot.com",
  messagingSenderId: "257344257735",
  appId: "1:257344257735:web:93fdcd085f0b3635c248e2"
};

firebase.initializeApp(firebaseConfig);

export default firebase;