// reducer load
export const LOADING = "LOADING";
export const LOAD_SCHOOL_DATA = "LOAD_SCHOOL_DATA";
export const SET_ERROR = "SET_ERROR";
export const INCREMENT_ATTENDANCE = "INCREMENT_ATTENDANCE";
export const DECREMENT_ATTENDANCE = "DECREMENT_ATTENDANCE";
export const SET_MESSAGE = "SET_MESSAGE";

export const AUTH = "AUTH";

export const REVERSE_ORDER ="REVERSE_ORDER";
export const SET_STUDENT ="SET_STUDENT";

export const EMAIL = "alan@alan.fr";
export const PASSWORD = "1234567890";

export const STUDENT_URL = "https://music-2020-f6d88.firebaseio.com";