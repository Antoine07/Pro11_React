
import React, { Component } from 'react';
import './App.css';

import Denomination from './components/Denomination';

class App extends Component{

  render(){

    return (
      < >
        <h1>Dénomination</h1>
        <Denomination />
      </>
    )
  }
}
export default App;
