import { SEND_NUMBER, RESET_CHOICE, SUBMIT_PROPOSITION, RESET_GAME} from '../constants/action-type'

export const sendNumber = (payload) => {
    return { 
        type: SEND_NUMBER, payload 
    }
};

export const resetChoice = () => {
    return { 
        type: RESET_CHOICE
    }
};

export const submitProposition = (payload) => {
    return {
        type: SUBMIT_PROPOSITION, payload 
    }
};

export const resetGame = () => {
    return {
        type : RESET_GAME
    }
}