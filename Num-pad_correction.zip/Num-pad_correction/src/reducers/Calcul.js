const SEND_NUMBER = 'SEND_NUMBER';
const RESET_CHOICE = 'RESET_CHOICE';
const SUBMIT_PROPOSITION = 'SUBMIT_PROPOSITION';
const RESET_GAME = 'RESET_GAME';

const max = 10;

const generateAllProposition = () => {
    let propositions = [];
    for(let i = 1; i < max + 1; i++){
        for(let j = 1; j < max + 1; j++){
            propositions.push({num1 : i, num2 : j, attempt : i * j});
        }
    }

    return propositions;
}

const generateOneProposition = (propositions) => {
    propositions = shuffle(propositions);

    return propositions.shift();
}

const shuffle = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }

    return array;
}

const propositions = generateAllProposition();
const proposition = generateOneProposition(propositions);

const count = propositions.length;


const init = () => {

    let propositions = generateAllProposition();
    let proposition = generateOneProposition(propositions);

    const reset = {
        propositions : propositions,
        proposition : proposition,
        score : 0,
        values : [],
        count : max  * max  -1,
        status : "progress",
        message : null,
        feedback : null,
        success : false
    }

    return reset
}

const stateInit = { ...init() }

export default (state = stateInit, action = {}) => {
    switch (action.type) {

        case SEND_NUMBER:

            return { 
                ...state, 
                values : [ ...state.values, action.payload  ],
                feedback : null
            }

        case SUBMIT_PROPOSITION:

            // calcul de la proposition
            // transformer en valeur decimale
            // attention à l'ordre dans le array inverser pour les puissances de 10
            let res = 0;
            const len = action.payload.length; // pour les puissances de 10

            action.payload.map(
                (num, index) => {
                    res += num * 10 **( len - (index + 1 ) ) 
                }
            );
            const { num1, num2, attempt } = state.proposition;
            const score = (attempt === res) + 0 ;

            const feedback = score == 0 ?
             `
             Mauvaise réponse, la bonne réponse était :
             ${num1} x ${num2} = ${attempt}
             ` : 
             `
             Super ! C'est la bonne réponse :
             ${num1} x ${num2} = ${attempt}
             `

            const proposition =  generateOneProposition(state.propositions);
            const propositions = state.propositions;
            const count = state.propositions.length;

            const status = (count === 0)?  "termineted" : state.status;
            const success = score === 1;

            return { 
                ...state, 
                score : state.score + score, 
                values : [],
                proposition : proposition,
                propositions : propositions,
                count : count,
                status : status,
                message : (score ==0)? 'Raté...' : 'Bravo !',
                feedback : feedback,
                success : success
            };

        case RESET_GAME :

            console.log( { ...state, ...init() } );

            return { ...state, ...init() }
        
        case RESET_CHOICE:

            return { ...state, values : [] }

        default:
            return state;
    }
}