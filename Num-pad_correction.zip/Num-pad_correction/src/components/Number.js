import React, { Component } from 'react';
import { connect } from 'react-redux';

import { sendNumber } from '../actions/actions';

import './Number.scss'

class Number extends Component {
    constructor(props) {
        super(props);
    }

    handleNumber = () => {
        this.props.submitNumber(this.props.number);
    }

    render() { 

        const classes = ["btn", "btn-dark"];
        const { style } = this.props;

        classes.push(style)

        return (
            <button 
                type="button" 
                className={classes.join(' ')}
                onClick={this.handleNumber}
            >
            {this.props.number}
            </button>
        );
    }
}

const mapDispatchToProps = (dispatch) => {

    return {
        submitNumber: (number) => dispatch(sendNumber( number))
    }
};

export default connect(null, mapDispatchToProps)(Number);