import React, { Component } from 'react';

class Message extends Component {
    constructor(props) {
        super(props);
    }

  render() { 

    const { message, count } = this.props;

    let classes = ["alert"]
    if( this.props.success === true ) classes.push("alert-success");
    
    if( this.props.success === false )
        classes.push("alert-danger");
    else
        classes.push("alert-primary");

    classes = classes.join(' ');

    if( message == null ) return (
        <div className="alert alert-primary" role="alert">
            Vous avez {this.props.count} multiplications à faire.
            Utilisez les touches du clavier pour répondre.
            <br/>
            Bonne chance !
        </div>
    )

    return (
        <div className={classes} role="alert" >
           {message}
           {
            count === 0 ?
            <p>Votre score est : {this.store.score}</p> : null
           }
        </div>
    );
  }
}

export default Message;
