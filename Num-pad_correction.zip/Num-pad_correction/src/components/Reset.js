import React, { Component } from 'react';
import { connect } from 'react-redux';
import { resetChoice, resetGame } from '../actions/actions';

import './Reset.scss'

class Reset extends Component {
    constructor(props) {
        super(props);
    }

    handleReset = () => {
        
        if(this.props.type === 'termineted')
            this.props.resetGame();

        if(this.props.type === 'choice')
            this.props.resetChoice();
    }

    render() {

        const { type } = this.props;

        return (
            <button 
                type="button" 
                className="btn btn-danger"
                onClick={this.handleReset}
            >
            <small>Reset {type}</small>
            </button>
        );
    }
}

const mapDispatchToProps = (dispatch) => {

    return {
        resetChoice: () => dispatch(resetChoice()),
        resetGame: () => dispatch(resetGame()),

    }
};

export default connect(null, mapDispatchToProps)(Reset);