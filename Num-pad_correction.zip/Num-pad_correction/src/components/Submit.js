import React, { Component } from 'react';
import { connect } from 'react-redux';
import { submitProposition } from '../actions/actions';

import './Submit.scss'

class Submit extends Component {
    constructor(props) {
        super(props);
    }

    handleSubmit = () =>{
        
        // on peut lire les states qui ont changé
        this.props.sumbit(this.props.values);
    } 

    render() { 
        return (
            <button 
                className="btn btn-primary" 
                type="submit"
                onClick={this.handleSubmit}
            >
                {this.props.status}
            </button>
        );
    }
}

// lecture du state pour récupérer les données qui ont changé
const mapStateToProps = (state) => {

    return {
      values : state.values,
    };
  };


const mapDispatchToProps = (dispatch) => {

    return {
        sumbit: (values) => dispatch(submitProposition(values)),
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Submit);