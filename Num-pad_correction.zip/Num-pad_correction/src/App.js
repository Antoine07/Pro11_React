import React, { Component } from 'react';
import { connect } from 'react-redux';

import Number from './components/Number';
import Submit from './components/Submit';
import Reset from './components/Reset';
import Message from './components/Message';

import './App.scss';

class App extends Component {
  constructor(props) {
      super(props);
  }

  render() { 
    const { values, proposition, message, feedback, success, score, count } = this.props;
    const numbers = Array.from(Array(10).keys()).reverse();

    if (this.props.status === 'progress'){
      const calcul =  (<p>Calculez : {proposition.num1} X {proposition.num2} = {values.map(number => number)}
      </p>); 
      return (
        <div className="container">
          <div className="row">
            <div className="col-md-8">
                <h1>Calcul mental !</h1>
                <Message  message={message} success={success} count={count}/>
                { feedback != null ? ( <Message message={feedback} />) : null }
                <Message message={calcul} />
                <div className="container-number">
                  {numbers.map((number, index) =>
                    (
                      <div className="Number">
                        <Number 
                          number={ number } 
                          key={index} 
                        />
                      </div>
                    )
                  )}
                </div>
                <Submit status="Go !" />
                <div className="Reset">
                  <Reset type="choice"/>
                </div>
                <div className="Reset">
                  <Reset type="termineted"/>
                </div>
            </div>
              <div className="col-md-4 Result">
                  <ul className="list-group">
                      <li className="list-group-item">
                        <small>Nombre de question(s) restante(s) : </small> {this.props.count}
                      </li>
                      <li className="list-group-item">
                        Score : {this.props.score}
                      </li>
                  </ul>
              </div>
            </div>
        </div>
      )
    }
    else
      return (
        <div className="container">
          <div className="row">
            <div className="col-md-12">
                <h1>Calcul mental !</h1>
                <Message 
                message="C'est terminé si vous voulez rejouer cliquez sur réinitialiser le jeu à l'aide du bouton si dessous :" 
                store = { this.props }
                />
                <div className="Reset">
                  <Reset type="termineted" style="reset"/>
                </div>
            </div>
          </div>
        </div>
      )
  }
}

// lire (lecture seule) le state dans Redux
const mapStateToProps = (state) => {

  return {
   ...state
  };
};


export default connect(mapStateToProps)(App);